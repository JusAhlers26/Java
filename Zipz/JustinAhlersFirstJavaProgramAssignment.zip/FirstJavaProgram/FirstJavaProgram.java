public class FirstJavaProgram {
    public static void main(String[] args) {
        System.out.println("My name is Justin Ahlers."
        + "\nI am 41 years young."
        + "\nMy hometown is Port Angeles");
    }
}